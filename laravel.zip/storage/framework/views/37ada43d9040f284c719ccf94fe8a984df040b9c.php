<?php $__env->startSection('content'); ?>




<div class="container mt-3">
  <div class="row">

    <div class="col-10 ">
      <div class="card">
        <div class="card-header bg-primary text-white">
           Update Category
        </div>
        <div class="card-body">

          <form action="<?php echo e(url('edit/brand/insert')); ?>" method="post">
            <?php echo csrf_field(); ?>
             <div class="form-group">
                 <input type="hidden" name="brand_id" value="<?php echo e($brand->id); ?>">
               <label class="font-weight-bold" >Brand Name</label>
               <input type="text" class="form-control" name="brand_name" value="<?php echo e($brand->brand_name); ?> " required="">
             </div>
              <button type="submit" class="btn btn-primary">Update</button>
          </form>


        </div>
      </div>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\laravel\resources\views/brand/brandedit.blade.php ENDPATH**/ ?>