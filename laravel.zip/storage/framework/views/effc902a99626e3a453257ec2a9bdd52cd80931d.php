<?php $__env->startSection('content'); ?>
<!-- content wrpper -->
<div class="content_wrapper">
  <!--middle content wrapper-->
  <!-- page content -->
  <div class="middle_content_wrapper">
    <section class="page_content">
      <!-- panel -->
      
      <!-- panel -->
      <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
      Add Brand
      </button>
      
      <!-- Modal -->
      <div class="modal fade mt-4" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="margin-top: 40px;">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Add Brand</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form action="<?php echo e(url('/insert/brand')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label class="font-weight-bold" >Brand Name</label>
                  <input type="text" class="form-control <?php $__errorArgs = ['brand_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "  placeholder="Enter your category name" name="brand_name" value="<?php echo e(old('brand_name')); ?>">
                  <?php $__errorArgs = ['brand_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
     <div class="panel mb-0">
      
      
      <div class="panel_header">
        <div class="panel_title">
          <span class="panel_icon"><i class="fas fa-border-all"></i></span><span>data table with search box</span>
        </div>
      </div>
      <div class="panel_body">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
          <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
        <div class="table-responsive">
          <table id="dataTableExample1" class="table table-bordered table-striped table-hover mb-2">
            <thead>
              <tr>
                <th>SL No.</th>
                <th>Category Name</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($loop->index + 1); ?></td>
                <td><?php echo e($cat->category_name); ?></td>
                <td>
                  <div class="btn-group" role="group">
                    <a href="<?php echo e(url('delete/category')); ?>/<?php echo e($cat->id); ?>" id="delete"  class="btn btn-sm btn-danger">Delete</a>
                    <a href="<?php echo e(url('edit/category')); ?>/<?php echo e($cat->id); ?>" class="btn btn-sm btn-primary">Edit</a>
                    <a href="<?php echo e(url('edit/category/'.$cat->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                  </div>
                </td>
                
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
          
        </div>
        </div> <!--/ panel body -->
        </div><!--/ panel --> 
      </section>
      <!--/ page content -->
      <!-- start code here... -->
      
      </div><!--/middle content wrapper-->
      </div><!--/ content wrapper -->
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/brand/brandview.blade.php ENDPATH**/ ?>