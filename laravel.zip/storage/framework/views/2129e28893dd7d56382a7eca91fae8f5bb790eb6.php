<?php $__env->startSection('content'); ?>




<div class="container mt-3">
  <div class="row">

    <div class="col-10 ">
      <div class="card">
        <div class="card-header bg-primary text-white">
           Add Category
        </div>
        <div class="card-body"> 
         <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
            <?php endif; ?>         
          <form action="<?php echo e(url('insert/category')); ?>" method="post">
            <?php echo csrf_field(); ?>
             <div class="form-group">
               <label class="font-weight-bold" >Category Name</label>               
               <input type="text" class="form-control"  placeholder="Enter your category name" name="category_name" value="">
             </div>
              <button type="submit" class="btn btn-primary">Add Category</button>                      
          </form>
          

        </div>
      </div>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('category.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/category/addcategory.blade.php ENDPATH**/ ?>